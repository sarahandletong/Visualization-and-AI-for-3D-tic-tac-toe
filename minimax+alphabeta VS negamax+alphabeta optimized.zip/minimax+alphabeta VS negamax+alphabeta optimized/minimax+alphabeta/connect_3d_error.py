class Connect3DError(Exception):
    pass